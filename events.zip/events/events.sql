-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 08. Aug 2020 um 17:55
-- Server-Version: 10.4.13-MariaDB
-- PHP-Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr13_onur_umar_bigevents`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `adress` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `events`
--

INSERT INTO `events` (`id`, `name`, `date`, `description`, `image`, `capacity`, `email`, `phone_number`, `adress`, `url`, `type`) VALUES
(2, 'Schonbrunn Event', '2020-08-19 11:53:00', 'Beautiful Event that reminds of royal times', 'https://cdn.pixabay.com/photo/2018/09/03/19/59/architecture-3652253_1280.jpg', 300, 'office@schonbrunn.de', 69956289176, 'Schonbrunn 1 1130 Wien', 'https://www.schoenbrunn.at/en/', 'event'),
(4, 'Theater an der Wien', '2021-01-01 00:00:00', 'Beautiful theater, thats shows amazing shows and its just amazing and super central', 'https://cdn.pixabay.com/photo/2013/02/26/01/10/florida-state-university-86197_1280.jpg', 300, 'office@theater.com', 699132324, 'Wienzeile 1 1060 Wien', 'https://www.theater-wien.at/de/home', 'theater'),
(5, 'Albertina', '2020-01-01 00:00:00', 'Great museum in the center of vienna, just amazing', 'https://cdn.pixabay.com/photo/2016/07/24/22/43/vienna-1539441_1280.jpg', 200, 'albertina@mail.com', 1, 'Felderstraße 6-8 1010 Wien', 'https://www.albertina.at/en/', 'art'),
(6, 'Cats Musical', '2021-11-19 16:18:00', 'Musical about cats, you dont need to know more', 'https://cdn.pixabay.com/photo/2019/05/01/01/19/cat-4169876_1280.jpg', 400, 'cats@ronacher.at', 1, 'Stadt 20 1010 Wien', 'https://www.musicalvienna.at/en/schedule-and-tickets/schedule/production/858/CATS/calendar', 'theater');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
